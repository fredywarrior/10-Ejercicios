/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PasajesAsientosAerolinea;

/**
 *
 * @author naxor
 */
public class AsientoTurista extends AsientoVuelo {
    private boolean incluyeSnack;
    
    
    //sinparametros

    public AsientoTurista() {
        
    //conparametros
    
    
    
    
    }

    public AsientoTurista(boolean incluyeSnack, String codigoAsiento, double precioTarifa, boolean reservado) {
        super(codigoAsiento, precioTarifa, reservado);
        this.incluyeSnack = incluyeSnack;
    }
    
    //getter

    public boolean isIncluyeSnack() {
        return incluyeSnack;
    }
    
    
    //setter

    public void setIncluyeSnack(boolean incluyeSnack) {
        this.incluyeSnack = incluyeSnack;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "AsientoTurista{" + "incluyeSnack=" + incluyeSnack + '}';
    }
    
    
    
    //metodos
    
    public void elegirMenuEstandar(){
        System.out.println("menu");
    }

    @Override
    public double calcularEquipajePermitido() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String emitirBoardingPass() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String validarPasaporte(String num) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
