/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PasajesAsientosAerolinea;

/**
 *
 * @author naxor
 */
public class BoardingDigital extends AsientoVuelo {
    private String codigoQR;
    
    //sinparametros

    public BoardingDigital() {
    }
    
    
    //conparametros

    public BoardingDigital(String codigoQR, String codigoAsiento, double precioTarifa, boolean reservado) {
        super(codigoAsiento, precioTarifa, reservado);
        this.codigoQR = codigoQR;
    }
    
    
    //getter

    public String getCodigoQR() {
        return codigoQR;
    }
    
    
    //setter

    public void setCodigoQR(String codigoQR) {
        this.codigoQR = codigoQR;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "BoardingDigital{" + "codigoQR=" + codigoQR + '}';
    }
    
    
    //metodos

    @Override
    public double calcularEquipajePermitido() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String emitirBoardingPass() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String validarPasaporte(String num) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
   
        
    
}
