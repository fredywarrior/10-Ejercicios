/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PasajesAsientosAerolinea;

/**
 *
 * @author naxor
 */
public class AsientoBusiness extends AsientoVuelo {
    private boolean accesoLounge;
    private CabinaPrivada suiteCabina;
    
    
    //sinparametros

    public AsientoBusiness() {
    }
    
    
    
    //con parametros

    public AsientoBusiness(boolean accesoLounge, CabinaPrivada suiteCabina, String codigoAsiento, double precioTarifa, boolean reservado) {
        super(codigoAsiento, precioTarifa, reservado);
        this.accesoLounge = accesoLounge;
        this.suiteCabina = suiteCabina;
    }
    
    
    //getter

    public boolean isAccesoLounge() {
        return accesoLounge;
    }

    public CabinaPrivada getSuiteCabina() {
        return suiteCabina;
    }
    
    
    //setter

    public void setAccesoLounge(boolean accesoLounge) {
        this.accesoLounge = accesoLounge;
    }

    public void setSuiteCabina(CabinaPrivada suiteCabina) {
        this.suiteCabina = suiteCabina;
    }
    
    
   //overroide

    @Override
    public String toString() {
        return "AsientoBusiness{" + "accesoLounge=" + accesoLounge + ", suiteCabina=" + suiteCabina + '}';
    }
    
    
    //metodos
    
    public void solicitarChampagne(){
        System.out.println("champaña");
    }

    @Override
    public double calcularEquipajePermitido() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String emitirBoardingPass() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String validarPasaporte(String num) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
