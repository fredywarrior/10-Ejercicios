/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PasajesAsientosAerolinea;

/**
 *
 * @author naxor
 */
public interface CheckInOnLine  {
    String emitirBoardingPass();
    String validarPasaporte (String num);
    
}
