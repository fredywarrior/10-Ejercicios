/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PasajesAsientosAerolinea;

/**
 *
 * @author naxor
 */
public abstract class AsientoVuelo implements CheckInOnLine{
    private String codigoAsiento;
    private double precioTarifa;
    private boolean reservado;
    
    //sinparametros 

    public AsientoVuelo() {
    }
    
    
    //conparametros

    public AsientoVuelo(String codigoAsiento, double precioTarifa, boolean reservado) {
        this.codigoAsiento = codigoAsiento;
        this.precioTarifa = precioTarifa;
        this.reservado = reservado;
    }
    
    
    //getter

    public String getCodigoAsiento() {
        return codigoAsiento;
    }

    public double getPrecioTarifa() {
        return precioTarifa;
    }

    public boolean isReservado() {
        return reservado;
    }
    
    
    //setter

    public void setCodigoAsiento(String codigoAsiento) {
        this.codigoAsiento = codigoAsiento;
    }

    public void setPrecioTarifa(double precioTarifa) {
        this.precioTarifa = precioTarifa;
    }

    public void setReservado(boolean reservado) {
        this.reservado = reservado;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "AsientoVuelo{" + "codigoAsiento=" + codigoAsiento + ", precioTarifa=" + precioTarifa + ", reservado=" + reservado + '}';
    }
    
    
    //metodos
    
    public void reservadaAsiento(){
        System.out.println("asientovich"); }
        
    public abstract double calcularEquipajePermitido();
    
  
        
    
    }
    
    

