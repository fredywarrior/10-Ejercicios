/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PasajesAsientosAerolinea;

/**
 *
 * @author naxor
 */
public class CabinaPrivada {
    private int numPantallaHD;
    private boolean asientoReclinable180;
    
    //sinparametros

    public CabinaPrivada() {
    }
    
    
    //conparametros

    public CabinaPrivada(int numPantallaHD, boolean asientoReclinable180) {
        this.numPantallaHD = numPantallaHD;
        this.asientoReclinable180 = asientoReclinable180;
    }
    
    
    //getter

    public int getNumPantallaHD() {
        return numPantallaHD;
    }

    public boolean isAsientoReclinable180() {
        return asientoReclinable180;
    }
    
    
    //setter

    public void setNumPantallaHD(int numPantallaHD) {
        this.numPantallaHD = numPantallaHD;
    }

    public void setAsientoReclinable180(boolean asientoReclinable180) {
        this.asientoReclinable180 = asientoReclinable180;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "CabinaPrivada{" + "numPantallaHD=" + numPantallaHD + ", asientoReclinable180=" + asientoReclinable180 + '}';
    }
    
    
    //metodos
    
    public boolean activarMasaje(){
        System.out.println("masajovich");
        return true;
        
    }
         
    
}
