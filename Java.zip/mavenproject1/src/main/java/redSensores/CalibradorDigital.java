/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package redSensores;

/**
 *
 * @author UsuarioCompuElite
 */
public class CalibradorDigital {
    private String fechaUltimaCalibracion;
    private double margenError;
    //sin parametros

    public CalibradorDigital() {
    }
    //con parametros

    public CalibradorDigital(String fechaUltimaCalibracion, double margenError) {
        this.fechaUltimaCalibracion = fechaUltimaCalibracion;
        this.margenError = margenError;
    }
    //getters

    public String getFechaUltimaCalibracion() {
        return fechaUltimaCalibracion;
    }

    public double getMargenError() {
        return margenError;
    }
    //setters

    public void setFechaUltimaCalibracion(String fechaUltimaCalibracion) {
        this.fechaUltimaCalibracion = fechaUltimaCalibracion;
    }

    public void setMargenError(double margenError) {
        this.margenError = margenError;
    }

    @Override
    public String toString() {
        return "CalibradorDigital{" + "fechaUltimaCalibracion=" + fechaUltimaCalibracion + ", margenError=" + margenError + '}';
    }
    
    public void ajustarCeroAbsoluto(){
        System.out.println("Comportamiento base en CalibradorDigital");
    }
}
