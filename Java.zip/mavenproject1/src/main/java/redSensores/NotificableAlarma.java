/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package redSensores;

/**
 *
 * @author UsuarioCompuElite
 */
public interface NotificableAlarma {
    void dispararSirenaEmergencia();
    void enviarNotificacionMQTT();
}
