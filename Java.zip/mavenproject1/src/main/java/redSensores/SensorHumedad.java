/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package redSensores;

/**
 *
 * @author UsuarioCompuElite
 */
public class SensorHumedad extends SensorIndustrial {
    private double nivelPuntualPorcentaje;
    //sin parametros

    public SensorHumedad() {
    }
    //con parametros

    public SensorHumedad(double nivelPuntualPorcentaje, String idSensor, String ubicaionArea, boolean activo) {
        super(idSensor, ubicaionArea, activo);
        this.nivelPuntualPorcentaje = nivelPuntualPorcentaje;
    }
    //getters

    public double getNivelPuntualPorcentaje() {
        return nivelPuntualPorcentaje;
    }
    //setters

    public void setNivelPuntualPorcentaje(double nivelPuntualPorcentaje) {
        this.nivelPuntualPorcentaje = nivelPuntualPorcentaje;
    }

    @Override
    public String toString() {
        return "SensorHumedad{" + "nivelPuntualPorcentaje=" + nivelPuntualPorcentaje + '}';
    }
    public double calcularPuntoRocio(){
        System.out.println("Metorodo propio de sensorHumedad");
        return 0;
    }

    @Override
    public double tomarLectura() {
        System.out.println("Comportamiento tomar lectura");
        return 0;
    }

    @Override
    public void dispararSirenaEmergencia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void enviarNotificacionMQTT() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
            
}
