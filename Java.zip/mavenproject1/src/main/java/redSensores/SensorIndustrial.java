/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package redSensores;

/**
 *
 * @author UsuarioCompuElite
 */
public abstract class SensorIndustrial implements NotificableAlarma{
    private String idSensor;
    private String ubicaionArea;
    private boolean activo;
    //sin parametros

    public SensorIndustrial() {
    }
    //con parametros

    public SensorIndustrial(String idSensor, String ubicaionArea, boolean activo) {
        this.idSensor = idSensor;
        this.ubicaionArea = ubicaionArea;
        this.activo = activo;
    }
    //getters

    public String getIdSensor() {
        return idSensor;
    }

    public String getUbicaionArea() {
        return ubicaionArea;
    }

    public boolean isActivo() {
        return activo;
    }
    //setters

    public void setIdSensor(String idSensor) {
        this.idSensor = idSensor;
    }

    public void setUbicaionArea(String ubicaionArea) {
        this.ubicaionArea = ubicaionArea;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "SensorIndustrial{" + "idSensor=" + idSensor + ", ubicaionArea=" + ubicaionArea + ", activo=" + activo + '}';
    }
    public abstract double tomarLectura();
    public void recalibrar(){
        System.out.println("Comportamiento base en SensorIndustrial");
    }
}
