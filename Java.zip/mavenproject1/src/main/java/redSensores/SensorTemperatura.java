/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package redSensores;

/**
 *
 * @author UsuarioCompuElite
 */
public class SensorTemperatura extends SensorIndustrial{
    private double gradosCelsius;
    //sin parametros

    public SensorTemperatura() {
    }
    //con parametros

    public SensorTemperatura(double gradosCelsius, String idSensor, String ubicaionArea, boolean activo) {
        super(idSensor, ubicaionArea, activo);
        this.gradosCelsius = gradosCelsius;
    }
    //getters

    public double getGradosCelsius() {
        return gradosCelsius;
    }
    //setters

    public void setGradosCelsius(double gradosCelsius) {
        this.gradosCelsius = gradosCelsius;
    }

    @Override
    public String toString() {
        return "SensorTemperatura{" + "gradosCelsius=" + gradosCelsius + '}';
    }

    @Override
    public double tomarLectura() {
         System.out.println("Comportamiento tomar lectura");
        return 0;
    }

    @Override
    public void dispararSirenaEmergencia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void enviarNotificacionMQTT() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
