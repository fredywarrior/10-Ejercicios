/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package redSensores;

/**
 *
 * @author UsuarioCompuElite
 */
public class SensorPresion extends SensorIndustrial {
    private double presionPSI;
    private CalibradorDigital dispositivoCalibrador;
    //sin parametros

    public SensorPresion() {
    }
    //con parametros

    public SensorPresion(double presionPSI, CalibradorDigital dispositivoCalibrador, String idSensor, String ubicaionArea, boolean activo) {
        super(idSensor, ubicaionArea, activo);
        this.presionPSI = presionPSI;
        this.dispositivoCalibrador = dispositivoCalibrador;
    }
    //getters

    public double getPresionPSI() {
        return presionPSI;
    }

    public CalibradorDigital getDispositivoCalibrador() {
        return dispositivoCalibrador;
    }
    //setters

    public void setPresionPSI(double presionPSI) {
        this.presionPSI = presionPSI;
    }

    public void setDispositivoCalibrador(CalibradorDigital dispositivoCalibrador) {
        this.dispositivoCalibrador = dispositivoCalibrador;
    }

    @Override
    public String toString() {
        return "SensorPresion{" + "presionPSI=" + presionPSI + ", dispositivoCalibrador=" + dispositivoCalibrador + '}';
    }
    public void mediDeltaPresion(){
        System.out.println("Comportamiento base SensorPresion");
    }

    @Override
    public double tomarLectura() {
         System.out.println("Comportamiento tomar lectura");
        return 0;
    }
    @Override
    public void dispararSirenaEmergencia() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void enviarNotificacionMQTT() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
