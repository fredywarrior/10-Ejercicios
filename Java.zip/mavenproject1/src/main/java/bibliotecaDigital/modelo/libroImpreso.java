/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaDigital.modelo;

/**
 *
 * @author naxor
 */
public class libroImpreso extends recursoBiblioteca {
 
 private int numPaginas;
 private String tipoEmpastado;
 
 //sin parametros

    public libroImpreso() {
    }
 
 //con parametros

    public libroImpreso(int numPaginas, String tipoEmpastado, String id, String titulo, boolean disponible) {
        super(id, titulo, disponible);
        this.numPaginas = numPaginas;
        this.tipoEmpastado = tipoEmpastado;
    }
    
    //getters

    public int getNumPaginas() {
        return numPaginas;
    }

    public String getTipoEmpastado() {
        return tipoEmpastado;
    }
    
    //setters

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }

    public void setTipoEmpastado(String tipoEmpastado) {
        this.tipoEmpastado = tipoEmpastado;
    }
    
    //override

    @Override
    public String toString() {
        return "libroImpreso{" + "numPaginas=" + numPaginas + ", tipoEmpastado=" + tipoEmpastado + '}';
    }
    
    //metodos
    
    public void hojearPaginas(){
        System.out.println("hojear");
    }

    @Override
    public void descargar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
