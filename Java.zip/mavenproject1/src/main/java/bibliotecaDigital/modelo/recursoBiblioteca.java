/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaDigital.modelo;

/**
 *
 * @author naxor
 */
public abstract class recursoBiblioteca implements Descargable {
   private String id;
   private String titulo;
   private boolean disponible;
   
   //sin parametro

    public recursoBiblioteca() {
    }
    
    //con parametros

    public recursoBiblioteca(String id, String titulo, boolean disponible) {
        this.id = id;
        this.titulo = titulo;
        this.disponible = disponible;
    }
    
    //getters

    public String getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

   
    
    
    //setters

    public void setId(String id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    @Override
    public String toString() {
        return "recursoBiblioteca{" + "id=" + id + ", titulo=" + titulo + ", disponible=" + disponible + '}';
    }
    
    //metodos
    
    public void prestar (){
        System.out.println("prestar");}
    public void devolver(){
        System.out.println("devolver");}
    public boolean isDisponible(){
        System.out.println("isdispo");
          return true;
            
                
    }
            
            
           

   
}
