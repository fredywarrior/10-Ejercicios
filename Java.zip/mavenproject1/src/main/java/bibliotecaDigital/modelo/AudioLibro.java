/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaDigital.modelo;

/**
 *
 * @author naxor
 */
public class AudioLibro extends recursoBiblioteca{

    private double duracionMinutos;
    private SoporteTecnico soporte;
    
    //sinparametros{

    public AudioLibro() {
    }
    
    //conparametros

    public AudioLibro(double duracionMinutos, SoporteTecnico soporte, String id, String titulo, boolean disponible) {
        super(id, titulo, disponible);
        this.duracionMinutos = duracionMinutos;
        this.soporte = soporte;
    }

    //getters

    public double getDuracionMinutos() {
        return duracionMinutos;
    }

    public SoporteTecnico getSoporte() {
        return soporte;
    }
    
    //setters

    public void setDuracionMinutos(double duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public void setSoporte(SoporteTecnico soporte) {
        this.soporte = soporte;
    }
    
    //override

    @Override
    public String toString() {
        return "AudioLibro{" + "duracionMinutos=" + duracionMinutos + ", soporte=" + soporte + '}';
    }
    
    //metodos
    
    public void reproducirMuestra (){
        System.out.println("muestrovich"); 
           
    }

    @Override
    public void descargar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
   
    
    
    
        
}

