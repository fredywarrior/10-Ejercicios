/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaDigital.modelo;

/**
 *
 * @author naxor
 */
public class RevistaAcademia extends recursoBiblioteca {

private int numeroEdicion;
private String doiLicencia;

//sinparametros

    public RevistaAcademia() {
    }

//conparametros

    public RevistaAcademia(int numeroEdicion, String doiLicencia, String id, String titulo, boolean disponible) {
        super(id, titulo, disponible);
        this.numeroEdicion = numeroEdicion;
        this.doiLicencia = doiLicencia;
    }
    
    //getters

    public int getNumeroEdicion() {
        return numeroEdicion;
    }

    public String getDoiLicencia() {
        return doiLicencia;
    }
    
    //setters

    public void setNumeroEdicion(int numeroEdicion) {
        this.numeroEdicion = numeroEdicion;
    }

    public void setDoiLicencia(String doiLicencia) {
        this.doiLicencia = doiLicencia;
    }
    
    //override

    @Override
    public String toString() {
        return "RevistaAcademia{" + "numeroEdicion=" + numeroEdicion + ", doiLicencia=" + doiLicencia + '}';
    }
    
    //metodos

    @Override
    public void descargar() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    

    
}
