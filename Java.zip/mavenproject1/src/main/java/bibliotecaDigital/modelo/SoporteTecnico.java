/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bibliotecaDigital.modelo;

/**
 *
 * @author naxor
 */
public class SoporteTecnico {
private String nombreFormato; 
private boolean activo;

//sinparametros

    public SoporteTecnico() {
    }

//conparametros

    public SoporteTecnico(String nombreFormato, boolean activo) {
        this.nombreFormato = nombreFormato;
        this.activo = activo;
    }
    
    //getters

    
       
   

    public boolean isActivo() {
        return activo;
    }
    
    //setters

    public void setNombreFormato(String nombreFormato) {
        this.nombreFormato = nombreFormato;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }
    
    //override

    @Override
    public String toString() {
        return "SoporteTecnico{" + "nombreFormato=" + nombreFormato + ", activo=" + activo + '}';
    }
    
    //metodos
    
   public String getNombreFormato(){
       System.out.println("NF");
       return null;
   }
          
}
