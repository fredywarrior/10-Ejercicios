/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionMedicaHospitalaria;

/**
 *
 * @author naxor
 */
public class Quirofano {
 
    private String codigoSala;
    private boolean esterilizado;
    
    //sinparametros

    public Quirofano() {
    }
    
    //conparametros

    public Quirofano(String codigoSala, boolean esterilizado) {
        this.codigoSala = codigoSala;
        this.esterilizado = esterilizado;
    }
    
    //getters

    public String getCodigoSala() {
        return codigoSala;
    }

   
    
    
    //setters

    public void setCodigoSala(String codigoSala) {
        this.codigoSala = codigoSala;
    }

    public void setEsterilizado(boolean esterilizado) {
        this.esterilizado = esterilizado;
    }
    
    //overroide

    @Override
    public String toString() {
        return "Quirofano{" + "codigoSala=" + codigoSala + ", esterilizado=" + esterilizado + '}';
    }
    
    //metodos
    
    public boolean isEsterelizado(){
        System.out.println("esteril");
        return true;
}}
