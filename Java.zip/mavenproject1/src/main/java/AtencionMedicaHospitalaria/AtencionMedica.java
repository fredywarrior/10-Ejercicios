/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionMedicaHospitalaria;

/**
 *
 * @author naxor
 */
public abstract class AtencionMedica implements FacturableDigital {
  private String codigoAtencion;
  private double costoBase;
  
  //sinparametros

    public AtencionMedica() {
    }
  
  //conparametros

    public AtencionMedica(String codigoAtencion, double costoBase) {
        this.codigoAtencion = codigoAtencion;
        this.costoBase = costoBase;
    }
    
    //getters

    public String getCodigoAtencion() {
        return codigoAtencion;
    }

    public double getCostoBase() {
        return costoBase;
    }
    
    //setters

    public void setCodigoAtencion(String codigoAtencion) {
        this.codigoAtencion = codigoAtencion;
    }

    public void setCostoBase(double costoBase) {
        this.costoBase = costoBase;
    }
    
    //overroide

    @Override
    public String toString() {
        return "AtencionMedica{" + "codigoAtencion=" + codigoAtencion + ", costoBase=" + costoBase + '}';
    }
    
    //metodo
    
    public abstract double calcularCostoTotal();
    public String registrarDiagnostico (String diag){
        System.out.println("diagnostico");
        return null;
                
    }
    
          
}
