/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionMedicaHospitalaria;

/**
 *
 * @author naxor
 */
public class Telemedicina extends AtencionMedica {
  
    private String plataformaVideo;
    
    //sinparametros

    public Telemedicina() {
    }
    
    //conparametros

    public Telemedicina(String plataformaVideo, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.plataformaVideo = plataformaVideo;
    }
    
    //getters

    public String getPlataformaVideo() {
        return plataformaVideo;
    }
    
    //setters

    public void setPlataformaVideo(String plataformaVideo) {
        this.plataformaVideo = plataformaVideo;
    }
    
    //overroide

    @Override
    public String toString() {
        return "Telemedicina{" + "plataformaVideo=" + plataformaVideo + '}';
    }

   
    @Override
    public double calcularCostoTotal() {
        System.out.println("calculartotal");
        return 0;
    }


    @Override
    public String generarFacturaXML() {
        System.out.println("factura");
        return null;
    }

    @Override
    public String enviarPorCorreo() {
        System.out.println("correo");
        return null;
    }
    
    
    
}
