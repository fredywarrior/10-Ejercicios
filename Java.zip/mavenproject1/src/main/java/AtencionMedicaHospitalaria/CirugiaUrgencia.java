/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionMedicaHospitalaria;

/**
 *
 * @author naxor
 */
public class CirugiaUrgencia extends AtencionMedica {
 
    private double horasDuracion;
    private Quirofano quirofanoAsignado;
     
    //sinparametros

    public CirugiaUrgencia() {
    }
    
    //conparametros

    public CirugiaUrgencia(double horasDuracion, Quirofano quirofanoAsignado, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.horasDuracion = horasDuracion;
        this.quirofanoAsignado = quirofanoAsignado;
    }
    
    //getters

    public double getHorasDuracion() {
        return horasDuracion;
    }

    public Quirofano getQuirofanoAsignado() {
        return quirofanoAsignado;
    }
    
    //setters

    public void setHorasDuracion(double horasDuracion) {
        this.horasDuracion = horasDuracion;
    }

    public void setQuirofanoAsignado(Quirofano quirofanoAsignado) {
        this.quirofanoAsignado = quirofanoAsignado;
    }
    
    //overroide

    @Override
    public String toString() {
        return "CirugiaUrgencia{" + "horasDuracion=" + horasDuracion + ", quirofanoAsignado=" + quirofanoAsignado + '}';
    }

    
    @Override
    public double calcularCostoTotal() {
        System.out.println("calculartotal");
        return 0;
    }

    @Override
    public String generarFacturaXML() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String enviarPorCorreo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void prepararEquipo(){
        System.out.println("equipo");
        
    }
}
