/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AtencionMedicaHospitalaria;

/**
 *
 * @author naxor
 */
public class ConsultaGeneral extends AtencionMedica {
    
    private boolean esRevisionRutina;
    
    //sinparametros

    public ConsultaGeneral() {
    }
    
    //conparametros

    public ConsultaGeneral(boolean esRevisionRutina, String codigoAtencion, double costoBase) {
        super(codigoAtencion, costoBase);
        this.esRevisionRutina = esRevisionRutina;
    }
    
    //getters

    public boolean isEsRevisionRutina() {
        return esRevisionRutina;
    }
    
    //setters

    public void setEsRevisionRutina(boolean esRevisionRutina) {
        this.esRevisionRutina = esRevisionRutina;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "ConsultaGeneral{" + "esRevisionRutina=" + esRevisionRutina + '}';
    }

    @Override
    public double calcularCostoTotal() {
        System.out.println("calculartotal");
        return 0;
    }

    @Override
    public String generarFacturaXML() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String enviarPorCorreo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    public void emitirRecetaMedica() {
        System.out.println("recetamedica");
        
    }
    
}
