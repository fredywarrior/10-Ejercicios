/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flota_vehiculos.modelo;

/**
 *
 * @author UsuarioCompuElite
 */
public class BateriaLitio {
    private double capacidadKWh;
    private int porcentajeCarga;
    //sin parametros

    public BateriaLitio() {
    }
    //con parametros

    public BateriaLitio(double capacidadKWh, int porcentajeCarga) {
        this.capacidadKWh = capacidadKWh;
        this.porcentajeCarga = porcentajeCarga;
    }
    //getters

    public double getCapacidadKWh() {
        return capacidadKWh;
    }

    public int getPorcentajeCarga() {
        return porcentajeCarga;
    }
    
    public void setCapacidadKWh(double capacidadKWh) {
        this.capacidadKWh = capacidadKWh;
    }

    //setters
    public void setPorcentajeCarga(int porcentajeCarga) {
        this.porcentajeCarga = porcentajeCarga;
    }

    @Override
    public String toString() {
        return "BateriaLitio{" + "capacidadKWh=" + capacidadKWh + ", porcentajeCarga=" + porcentajeCarga + '}';
    }
    
    public int getPorcentaje(){
        System.out.println("Ejectuando baterialitio");
        return 0;
    }
}
