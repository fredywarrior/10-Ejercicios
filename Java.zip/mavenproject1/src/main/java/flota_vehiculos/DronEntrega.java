/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flota_vehiculos.modelo;

/**
 *
 * @author UsuarioCompuElite
 */
public class DronEntrega extends VehiculoAutonomo {
    private double PesoMaxPaquete;
    //sin parametros

    public DronEntrega() {
    }
    //con parametros

    public DronEntrega(double PesoMaxPaquete, String vin, double velocidadMax, boolean enRuta) {
        super(vin, velocidadMax, enRuta);
        this.PesoMaxPaquete = PesoMaxPaquete;
    }
    //getters

    public double getPesoMaxPaquete() {
        return PesoMaxPaquete;
    }
    //setters

    public void setPesoMaxPaquete(double PesoMaxPaquete) {
        this.PesoMaxPaquete = PesoMaxPaquete;
    }

    @Override
    public String toString() {
        return "DronEntrega{" + "PesoMaxPaquete=" + PesoMaxPaquete + '}';
    }
    
    
    @Override
    public String obtenerCoordenadas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void transmitirTelemetria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
