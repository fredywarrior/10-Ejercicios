/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package flota_vehiculos.modelo;

/**
 *
 * @author UsuarioCompuElite
 */
public interface RastreableGPSInterface {
    String obtenerCoordenadas();
    void transmitirTelemetria();
}
