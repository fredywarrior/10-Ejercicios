/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flota_vehiculos.modelo;

/**
 *
 * @author UsuarioCompuElite
 */
public class BusExpreso extends VehiculoAutonomo {
    private int capacidadPasajeros;
    //sin parametros

    public BusExpreso() {
    }
    //con parametros

    public BusExpreso(int capacidadPasajeros, String vin, double velocidadMax, boolean enRuta) {
        super(vin, velocidadMax, enRuta);
        this.capacidadPasajeros = capacidadPasajeros;
    }
    //getters 

    public int getCapacidadPasajeros() {
        return capacidadPasajeros;
    }
    //setters

    public void setCapacidadPasajeros(int capacidadPasajeros) {
        this.capacidadPasajeros = capacidadPasajeros;
    }

    @Override
    public String toString() {
        return "BusExpreso{" + "capacidadPasajeros=" + capacidadPasajeros + '}';
    }
    public void anunciarSiguienteParada(){
        System.out.println("Metodo propio de BusExpreso");
    }

    @Override
    public String obtenerCoordenadas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void transmitirTelemetria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}


