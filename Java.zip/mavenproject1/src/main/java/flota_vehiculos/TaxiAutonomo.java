/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flota_vehiculos.modelo;

/**
 *
 * @author UsuarioCompuElite
 */
public class TaxiAutonomo extends VehiculoAutonomo{
    private double taridaPorKm;
    private BateriaLitio packBaterias;
    //sin parametros

    public TaxiAutonomo() {
    }
    //con parametros

    public TaxiAutonomo(double taridaPorKm, BateriaLitio packBaterias, String vin, double velocidadMax, boolean enRuta) {
        super(vin, velocidadMax, enRuta);
        this.taridaPorKm = taridaPorKm;
        this.packBaterias = packBaterias;
    }
    
    //getters

    public double getTaridaPorKm() {
        return taridaPorKm;
    }

    public BateriaLitio getPackBaterias() {
        return packBaterias;
    }
    //setters

    public void setTaridaPorKm(double taridaPorKm) {
        this.taridaPorKm = taridaPorKm;
    }

    public void setPackBaterias(BateriaLitio packBaterias) {
        this.packBaterias = packBaterias;
    }

    @Override
    public String toString() {
        return "TaxiAutonomo{" + "taridaPorKm=" + taridaPorKm + ", packBaterias=" + packBaterias + '}';
    }
    public void solicitarRecargaRapida(){
        System.out.println("Operacion con composicion en taxiAutonomo");
    }

    @Override
    public String obtenerCoordenadas() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void transmitirTelemetria() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
