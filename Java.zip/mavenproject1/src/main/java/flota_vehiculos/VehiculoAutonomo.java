/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package flota_vehiculos.modelo;

/**
 *
 * @author UsuarioCompuElite
 */
public abstract class VehiculoAutonomo implements RastreableGPSInterface{
    private String vin;
    private double velocidadMax;
    private boolean enRuta;
    
    //sin parametros

    public VehiculoAutonomo() {
    }
    //con parametros

    public VehiculoAutonomo(String vin, double velocidadMax, boolean enRuta) {
        this.vin = vin;
        this.velocidadMax = velocidadMax;
        this.enRuta = enRuta;
    }
    
    //getters 

    public String getVin() {
        return vin;
    }

    public double getVelocidadMax() {
        return velocidadMax;
    }

    public boolean isEnRuta() {
        return enRuta;
    }
    //setters

    public void setVin(String vin) {
        this.vin = vin;
    }

    public void setVelocidadMax(double velocidadMax) {
        this.velocidadMax = velocidadMax;
    }

    public void setEnRuta(boolean enRuta) {
        this.enRuta = enRuta;
    }

    @Override
    public String toString() {
        return "VehiculoAutonomo{" + "vin=" + vin + ", velocidadMax=" + velocidadMax + ", enRuta=" + enRuta + '}';
    }
    
    public String iniciarRuta(String destino){
        System.out.println("Comportamiento base en vehiculo");
        return null;
    }
    public void frenarEmergencia(){
        System.out.println("Comportamiento Frenado de emergencia");
    }
}
