/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ReservaHotelCincoEstrellas;

/**
 *
 * @author naxor
 */
public interface SanitizableAutomatico {
    boolean iniciarCicloDesinfeccion();
    String obtenerReporteSeguridad();
    
            
    
}
