/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReservaHotelCincoEstrellas;

/**
 *
 * @author naxor
 */
public class ServicioMayordomo {
    private String nombreMayordomo;
    private int turnosDisponibles;
    
    //sinparametros

    public ServicioMayordomo() {
    }
    
    //conparametros

    public ServicioMayordomo(String nombreMayordomo, int turnosDisponibles) {
        this.nombreMayordomo = nombreMayordomo;
        this.turnosDisponibles = turnosDisponibles;
    }
    
    //getters

    public String getNombreMayordomo() {
        return nombreMayordomo;
    }

    public int getTurnosDisponibles() {
        return turnosDisponibles;
    }
    
    //setter

    public void setNombreMayordomo(String nombreMayordomo) {
        this.nombreMayordomo = nombreMayordomo;
    }

    public void setTurnosDisponibles(int turnosDisponibles) {
        this.turnosDisponibles = turnosDisponibles;
    }
    
    //overroide

    @Override
    public String toString() {
        return "ServicioMayordomo{" + "nombreMayordomo=" + nombreMayordomo + ", turnosDisponibles=" + turnosDisponibles + '}';
    }
    
    
    //metodos
    
    public void atenderLLamadaVIP(){
        System.out.println("atender llamada");
    }
          
   
    
}
