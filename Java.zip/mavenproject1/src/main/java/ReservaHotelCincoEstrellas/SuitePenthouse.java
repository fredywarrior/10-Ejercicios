/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReservaHotelCincoEstrellas;

/**
 *
 * @author naxor
 */
public class SuitePenthouse extends HabitacionHotel {
    private boolean jacuzziPrivado;
    private ServicioMayordomo mayordomoVIP;
    
    //sinparametros

    public SuitePenthouse() {
    }
    
    //conparametros

    public SuitePenthouse(boolean jacuzziPrivado, ServicioMayordomo mayordomoVIP, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.jacuzziPrivado = jacuzziPrivado;
        this.mayordomoVIP = mayordomoVIP;
    }
    
    
    //getter

    public boolean isJacuzziPrivado() {
        return jacuzziPrivado;
    }

    public ServicioMayordomo getMayordomoVIP() {
        return mayordomoVIP;
    }
    
    //setter

    public void setJacuzziPrivado(boolean jacuzziPrivado) {
        this.jacuzziPrivado = jacuzziPrivado;
    }

    public void setMayordomoVIP(ServicioMayordomo mayordomoVIP) {
        this.mayordomoVIP = mayordomoVIP;
    }
    
    //overroide

    @Override
    public String toString() {
        return "SuitePenthouse{" + "jacuzziPrivado=" + jacuzziPrivado + ", mayordomoVIP=" + mayordomoVIP + '}';
    }
    
    
    //metodos
    
    public void solicitarCenaGourmet(){
        System.out.println("cenovich");
    }

    @Override
    public int calcularCostoEstadia(int noches) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean iniciarCicloDesinfeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
