/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReservaHotelCincoEstrellas;

/**
 *
 * @author naxor
 */
public class SuiteTematica extends HabitacionHotel {
    private String tematicaDecoracion;
    
    //sinparametros

    public SuiteTematica() {
    }
    
    
    //conparametros

    public SuiteTematica(String tematicaDecoracion, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.tematicaDecoracion = tematicaDecoracion;
    }
    
    
    //getter

    public String getTematicaDecoracion() {
        return tematicaDecoracion;
    }
    
    
    //setter

    public void setTematicaDecoracion(String tematicaDecoracion) {
        this.tematicaDecoracion = tematicaDecoracion;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "SuiteTematica{" + "tematicaDecoracion=" + tematicaDecoracion + '}';
    }

    @Override
    public int calcularCostoEstadia(int noches) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean iniciarCicloDesinfeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
}
