/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReservaHotelCincoEstrellas;

/**
 *
 * @author naxor
 */
public class HabitacionEstandar extends HabitacionHotel {
    private int camasSupletorias;
    
    //sinparametros

    public HabitacionEstandar() {
    }
    
    //conparametros

    public HabitacionEstandar(int camasSupletorias, int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        super(numeroHabitacion, precioNocheBase, ocupada);
        this.camasSupletorias = camasSupletorias;
    }
    
    //getters

    public int getCamasSupletorias() {
        return camasSupletorias;
    }
    
    //setters

    public void setCamasSupletorias(int camasSupletorias) {
        this.camasSupletorias = camasSupletorias;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "HabitacionEstandar{" + "camasSupletorias=" + camasSupletorias + '}';
    }
    
    
    //metodos
    
    public void solicitarToallaExtra(){
        System.out.println("toalla");
    }

    @Override
    public int calcularCostoEstadia(int noches) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean iniciarCicloDesinfeccion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String obtenerReporteSeguridad() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
