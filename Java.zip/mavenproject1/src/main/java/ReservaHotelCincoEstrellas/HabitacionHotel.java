/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReservaHotelCincoEstrellas;

/**
 *
 * @author naxor
 */
public abstract class HabitacionHotel implements SanitizableAutomatico {
    private int numeroHabitacion;
    private double precioNocheBase;
    private boolean ocupada;
     
    //sinparametros

    public HabitacionHotel() {
    }
    
    //conparametros

    public HabitacionHotel(int numeroHabitacion, double precioNocheBase, boolean ocupada) {
        this.numeroHabitacion = numeroHabitacion;
        this.precioNocheBase = precioNocheBase;
        this.ocupada = ocupada;
    }
    
    //getters

    public int getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public double getPrecioNocheBase() {
        return precioNocheBase;
    }

    public boolean isOcupada() {
        return ocupada;
    }
    
    //setters

    public void setNumeroHabitacion(int numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public void setPrecioNocheBase(double precioNocheBase) {
        this.precioNocheBase = precioNocheBase;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "HabitacionHotel{" + "numeroHabitacion=" + numeroHabitacion + ", precioNocheBase=" + precioNocheBase + ", ocupada=" + ocupada + '}';
    }
    
    
    //metodos
    
    public abstract int calcularCostoEstadia(int noches);
    public void realizarCheckIn(){
            System.out.println("check");
}
            
    
}
