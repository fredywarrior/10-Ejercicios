/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PedidosCocinaRestaurante;

/**
 *
 * @author naxor
 */
public abstract class PlatilloMenu implements EmpacableTermico {
    private String idPlato;
    private String nombre;
    private double precioBase;
    
    //sinparametros

    public PlatilloMenu() {
    }
    
    //conparametros

    public PlatilloMenu(String idPlato, String nombre, double precioBase) {
        this.idPlato = idPlato;
        this.nombre = nombre;
        this.precioBase = precioBase;
    }
    
    
    //getter

    public String getIdPlato() {
        return idPlato;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecioBase() {
        return precioBase;
    }
    
    //setter

    public void setIdPlato(String idPlato) {
        this.idPlato = idPlato;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "PlatilloMenu{" + "idPlato=" + idPlato + ", nombre=" + nombre + ", precioBase=" + precioBase + '}';
    }
    
    
    //metodos
    
    public abstract double calcularPrecioFinal();
    public void prepararPlato(){
        System.out.println("platovich");
    }
    
    
}
