/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PedidosCocinaRestaurante;

/**
 *
 * @author naxor
 */
public class PedidoDelivery extends PlatilloMenu{
    private String direccionEntrega;
    
    //sinparametros

    public PedidoDelivery() {
    }
    
    
    //conparametros

    public PedidoDelivery(String direccionEntrega, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.direccionEntrega = direccionEntrega;
    }
    
    
    //getter

    public String getDireccionEntrega() {
        return direccionEntrega;
    }
    
    
    //setter

    public void setDireccionEntrega(String direccionEntrega) {
        this.direccionEntrega = direccionEntrega;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "PedidoDelivery{" + "direccionEntrega=" + direccionEntrega + '}';
    }
    
    
    //metodos

    @Override
    public double calcularPrecioFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void sellarEmpaque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int tiempoConservacionMin() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
}
