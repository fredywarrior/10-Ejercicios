/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PedidosCocinaRestaurante;

/**
 *
 * @author naxor
 */
public class PlatoPrincipal extends PlatilloMenu {
    private String tipoProteina;
    private Sommelier sommelierAsignado;
    
    //sinparametros

    public PlatoPrincipal() {
    }
    
    
    //conparametros

    public PlatoPrincipal(String tipoProteina, Sommelier sommelierAsignado, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.tipoProteina = tipoProteina;
        this.sommelierAsignado = sommelierAsignado;
    }
    
    
    //getter

    public String getTipoProteina() {
        return tipoProteina;
    }

    public Sommelier getSommelierAsignado() {
        return sommelierAsignado;
    }
    
    
    //setter

    public void setTipoProteina(String tipoProteina) {
        this.tipoProteina = tipoProteina;
    }

    public void setSommelierAsignado(Sommelier sommelierAsignado) {
        this.sommelierAsignado = sommelierAsignado;
    }
    
    
    //overroide

    @Override
    public String toString() {
        return "PlatoPrincipal{" + "tipoProteina=" + tipoProteina + ", sommelierAsignado=" + sommelierAsignado + '}';
    }
    

    //metodos
    
    public void sugerirMaridaje(){
        System.out.println("maridaje");
    }

    @Override
    public double calcularPrecioFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void sellarEmpaque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int tiempoConservacionMin() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  
            
    
}
