/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PedidosCocinaRestaurante;

/**
 *
 * @author naxor
 */
public class Sommelier {
   private String nombreExperto;
   private int certificacionNivel;
   
   
   //sinparametros

    public Sommelier() {
    }
   
   
    //conparametros

    public Sommelier(String nombreExperto, int certificacionNivel) {
        this.nombreExperto = nombreExperto;
        this.certificacionNivel = certificacionNivel;
    }
    
    
    //getter

    public String getNombreExperto() {
        return nombreExperto;
    }

    public int getCertificacionNivel() {
        return certificacionNivel;
    }
    
    
    //setter

    public void setNombreExperto(String nombreExperto) {
        this.nombreExperto = nombreExperto;
    }

    public void setCertificacionNivel(int certificacionNivel) {
        this.certificacionNivel = certificacionNivel;
    }
    
   
    //overroide

    @Override
    public String toString() {
        return "Sommelier{" + "nombreExperto=" + nombreExperto + ", certificacionNivel=" + certificacionNivel + '}';
    }
    
    //metodos
    
    public String recomendarVino(String plato){
        System.out.println("Vino");
        return null;
    }
}
