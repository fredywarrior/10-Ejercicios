/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package PedidosCocinaRestaurante;

/**
 *
 * @author naxor
 */
public interface EmpacableTermico {
    void sellarEmpaque();
    int tiempoConservacionMin();
    
   
    
    
}
