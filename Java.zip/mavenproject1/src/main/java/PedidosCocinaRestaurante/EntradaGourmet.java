/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PedidosCocinaRestaurante;

/**
 *
 * @author naxor
 */
public class EntradaGourmet extends PlatilloMenu {
    private boolean esFrio;
    
    //sinparametros

    public EntradaGourmet() {
    }
    
    //conparametros

    public EntradaGourmet(boolean esFrio, String idPlato, String nombre, double precioBase) {
        super(idPlato, nombre, precioBase);
        this.esFrio = esFrio;
    }
    
    
    //getter

    public boolean isEsFrio() {
        return esFrio;
    }
    
    
    //setter

    public void setEsFrio(boolean esFrio) {
        this.esFrio = esFrio;
    }
    
    
    //overroide 

    @Override
    public String toString() {
        return "EntradaGourmet{" + "esFrio=" + esFrio + '}';
    }
    
    
    //metodos
    
    public void verificarAlergenos(){
        System.out.println("alergenos");
      
    }

    @Override
    public double calcularPrecioFinal() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void sellarEmpaque() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int tiempoConservacionMin() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
         
            
 
    
}
