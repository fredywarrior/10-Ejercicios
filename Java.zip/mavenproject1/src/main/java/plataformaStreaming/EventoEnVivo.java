/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plataformaStreaming;

/**
 *
 * @author UsuarioCompuElite
 */
public class EventoEnVivo extends ContenidoMedia {
    private int latenciaMs;
    private ServidorCDN nodoCDN;
    //sin parametros

    public EventoEnVivo() {
    }
    //con parametros

    public EventoEnVivo(int latenciaMs, ServidorCDN nodoCDN, String idMedia, String titulo, int duracionSeg) {
        super(idMedia, titulo, duracionSeg);
        this.latenciaMs = latenciaMs;
        this.nodoCDN = nodoCDN;
    }
    //getters

    public int getLatenciaMs() {
        return latenciaMs;
    }

    public ServidorCDN getNodoCDN() {
        return nodoCDN;
    }
    //setters

    public void setLatenciaMs(int latenciaMs) {
        this.latenciaMs = latenciaMs;
    }

    public void setNodoCDN(ServidorCDN nodoCDN) {
        this.nodoCDN = nodoCDN;
    }

    @Override
    public String toString() {
        return "EventoEnVivo{" + "latenciaMs=" + latenciaMs + ", nodoCDN=" + nodoCDN + '}';
    }
    public void ajustarCalidadDynamic(){
        System.out.println("Comportamiento propio de EventoEnVivo");
    }

    @Override
    public boolean guardarEnCache() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean verificarEspacioDisk() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
