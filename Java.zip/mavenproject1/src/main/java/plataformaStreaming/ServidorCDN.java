/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plataformaStreaming;

/**
 *
 * @author UsuarioCompuElite
 */
public class ServidorCDN {
    private String ipNodo;
    private double anchoBandaGbps;
    // sin parametros

    public ServidorCDN() {
    }
    //con parametros

    public ServidorCDN(String ipNodo, double anchoBandaGbps) {
        this.ipNodo = ipNodo;
        this.anchoBandaGbps = anchoBandaGbps;
    }
    //getters

    public String getIpNodo() {
        return ipNodo;
    }

    public double getAnchoBandaGbps() {
        return anchoBandaGbps;
    }
    //setters

    public void setIpNodo(String ipNodo) {
        this.ipNodo = ipNodo;
    }

    public void setAnchoBandaGbps(double anchoBandaGbps) {
        this.anchoBandaGbps = anchoBandaGbps;
    }

    @Override
    public String toString() {
        return "ServidorCDN{" + "ipNodo=" + ipNodo + ", anchoBandaGbps=" + anchoBandaGbps + '}';
    }
    
    public void balancearCarga(){
        System.out.println("Ejecutando en ServidorCDN");
    }
}
