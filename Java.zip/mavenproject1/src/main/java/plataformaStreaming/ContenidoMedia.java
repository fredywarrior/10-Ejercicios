/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plataformaStreaming;

/**
 *
 * @author UsuarioCompuElite
 */
public abstract class ContenidoMedia implements DescargableOffline {
    private String idMedia;
    private String titulo;
    private int duracionSeg;
    //sin parametros

    public ContenidoMedia() {
    }
    //con parametros

    public ContenidoMedia(String idMedia, String titulo, int duracionSeg) {
        this.idMedia = idMedia;
        this.titulo = titulo;
        this.duracionSeg = duracionSeg;
    }
    //getters

    public String getIdMedia() {
        return idMedia;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getDuracionSeg() {
        return duracionSeg;
    }
    //setters

    public void setIdMedia(String idMedia) {
        this.idMedia = idMedia;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDuracionSeg(int duracionSeg) {
        this.duracionSeg = duracionSeg;
    }

    @Override
    public String toString() {
        return "ContenidoMedia{" + "idMedia=" + idMedia + ", titulo=" + titulo + ", duracionSeg=" + duracionSeg + '}';
    }
    
    public void reproducir(){
        System.out.println("Reproduccion");
    }
    public void pausar(){
        System.out.println("Pausa");
    }
    
}
