/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plataformaStreaming;

/**
 *
 * @author UsuarioCompuElite
 */
public class PodcastEpisidio extends ContenidoMedia{
    private int numEpisodio;
    //sin parametros

    public PodcastEpisidio() {
    }
    //con parametros

    public PodcastEpisidio(int numEpisodio, String idMedia, String titulo, int duracionSeg) {
        super(idMedia, titulo, duracionSeg);
        this.numEpisodio = numEpisodio;
    }
    //getters

    public int getNumEpisodio() {
        return numEpisodio;
    }
    //setters

    public void setNumEpisodio(int numEpisodio) {
        this.numEpisodio = numEpisodio;
    }

    @Override
    public String toString() {
        return "PodcastEpisidio{" + "numEpisodio=" + numEpisodio + '}';
    }

    @Override
    public boolean guardarEnCache() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean verificarEspacioDisk() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
