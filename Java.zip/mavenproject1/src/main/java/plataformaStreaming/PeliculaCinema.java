/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package plataformaStreaming;

/**
 *
 * @author UsuarioCompuElite
 */
public class PeliculaCinema extends ContenidoMedia {
    private String director;
    //sin parametros

    public PeliculaCinema() {
    }
    //con parametros

    public PeliculaCinema(String director, String idMedia, String titulo, int duracionSeg) {
        super(idMedia, titulo, duracionSeg);
        this.director = director;
    }
    //getters

    public String getDirector() {
        return director;
    }
    //setters

    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public String toString() {
        return "PeliculaCinema{" + "director=" + director + '}';
    }
    public void mostrarTrailer(){
        System.out.println("Comportamiento propio de mostrarTrailer");
    }

    @Override
    public boolean guardarEnCache() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean verificarEspacioDisk() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
