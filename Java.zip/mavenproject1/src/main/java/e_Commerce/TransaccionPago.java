/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_Commerce;

/**
 *
 * @author UsuarioCompuElite
 */
public abstract class TransaccionPago implements VerificableBlockchain {
    private String idTransaccion;
    private double montoUSD;
    private boolean completado;
    //sin parametros

    public TransaccionPago() {
    }
    //con parametros

    public TransaccionPago(String idTransaccion, double montoUSD, boolean completado) {
        this.idTransaccion = idTransaccion;
        this.montoUSD = montoUSD;
        this.completado = completado;
    }
    //getters

    public String getIdTransaccion() {
        return idTransaccion;
    }

    public double getMontoUSD() {
        return montoUSD;
    }

    public boolean isCompletado() {
        return completado;
    }
    //setters

    public void setIdTransaccion(String idTransaccion) {
        this.idTransaccion = idTransaccion;
    }

    public void setMontoUSD(double montoUSD) {
        this.montoUSD = montoUSD;
    }

    public void setCompletado(boolean completado) {
        this.completado = completado;
    }

    @Override
    public String toString() {
        return "TransaccionPago{" + "idTransaccion=" + idTransaccion + ", montoUSD=" + montoUSD + ", completado=" + completado + '}';
    }
    public abstract boolean procesarPago();
    public String generarComprobante(){
        System.out.println("Comportamiento proceso pago");
        return null;    
    }
    
}
