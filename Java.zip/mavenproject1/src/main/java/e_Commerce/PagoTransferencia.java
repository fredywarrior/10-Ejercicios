/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_Commerce;

/**
 *
 * @author UsuarioCompuElite
 */
public class PagoTransferencia extends TransaccionPago{
    private String bancoOrigen;
    //sin parametros

    public PagoTransferencia() {
    }
    //con parametros

    public PagoTransferencia(String bancoOrigen, String idTransaccion, double montoUSD, boolean completado) {
        super(idTransaccion, montoUSD, completado);
        this.bancoOrigen = bancoOrigen;
    }
    //getters

    public String getBancoOrigen() {
        return bancoOrigen;
    }
    //setters

    public void setBancoOrigen(String bancoOrigen) {
        this.bancoOrigen = bancoOrigen;
    }

    @Override
    public String toString() {
        return "PagoTransferencia{" + "bancoOrigen=" + bancoOrigen + '}';
    }
    public void adjuntaComprobante(){
        System.out.println("Comportamiento propio de PagoTransferencia");
    }

    @Override
    public boolean procesarPago() {
        System.out.println("Comportamiento proceso pago");
        return true;
        
    }
    @Override
    public String obtenerHashConfirmacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int numeroConfirmaciones() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
