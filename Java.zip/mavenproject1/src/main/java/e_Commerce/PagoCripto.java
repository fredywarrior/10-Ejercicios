/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_Commerce;

/**
 *
 * @author UsuarioCompuElite
 */
public class PagoCripto extends TransaccionPago{
    private String walletDestino;
    private String redBlockain;
    //sin parametros

    public PagoCripto() {
    }
    //con parametros

    public PagoCripto(String walletDestino, String redBlockain, String idTransaccion, double montoUSD, boolean completado) {
        super(idTransaccion, montoUSD, completado);
        this.walletDestino = walletDestino;
        this.redBlockain = redBlockain;
    }
    //getters

    public String getWalletDestino() {
        return walletDestino;
    }

    public String getRedBlockain() {
        return redBlockain;
    }
    //setters

    public void setWalletDestino(String walletDestino) {
        this.walletDestino = walletDestino;
    }

    public void setRedBlockain(String redBlockain) {
        this.redBlockain = redBlockain;
    }

    @Override
    public String toString() {
        return "PagoCripto{" + "walletDestino=" + walletDestino + ", redBlockain=" + redBlockain + '}';
    }

    @Override
    public boolean procesarPago() {
        System.out.println("Comportamiento proceso pago");
        return true;
        
    }

    @Override
    public String obtenerHashConfirmacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int numeroConfirmaciones() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
