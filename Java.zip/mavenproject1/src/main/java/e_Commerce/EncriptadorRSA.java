/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_Commerce;

/**
 *
 * @author UsuarioCompuElite
 */
public class EncriptadorRSA {
    private int longitudLlave;
    private String tokenSeguridad;
    //sin parametros

    public EncriptadorRSA() {
    }
    //con parametros

    public EncriptadorRSA(int longitudLlave, String tokenSeguridad) {
        this.longitudLlave = longitudLlave;
        this.tokenSeguridad = tokenSeguridad;
    }
    //getters

    public int getLongitudLlave() {
        return longitudLlave;
    }

    public String getTokenSeguridad() {
        return tokenSeguridad;
    }
    //setters

    public void setLongitudLlave(int longitudLlave) {
        this.longitudLlave = longitudLlave;
    }

    public void setTokenSeguridad(String tokenSeguridad) {
        this.tokenSeguridad = tokenSeguridad;
    }

    @Override
    public String toString() {
        return "EncriptadorRSA{" + "longitudLlave=" + longitudLlave + ", tokenSeguridad=" + tokenSeguridad + '}';
    }
    public String encriptarDatos (String datos){
        System.out.println("Comportamiento propio de EncriptadorRSA");
        return null;
    }
}
