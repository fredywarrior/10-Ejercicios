/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package e_Commerce;

/**
 *
 * @author UsuarioCompuElite
 */
public class PagoTarjeta extends TransaccionPago{
    private String ultimos4Digitos;
    private EncriptadorRSA moduloRSA;
    //sin parametros

    public PagoTarjeta() {
    }
    //con parametros

    public PagoTarjeta(String ultimos4Digitos, EncriptadorRSA moduloRSA, String idTransaccion, double montoUSD, boolean completado) {
        super(idTransaccion, montoUSD, completado);
        this.ultimos4Digitos = ultimos4Digitos;
        this.moduloRSA = moduloRSA;
    }
    //getters

    public String getUltimos4Digitos() {
        return ultimos4Digitos;
    }

    public EncriptadorRSA getModuloRSA() {
        return moduloRSA;
    }
    //setters

    public void setUltimos4Digitos(String ultimos4Digitos) {
        this.ultimos4Digitos = ultimos4Digitos;
    }

    public void setModuloRSA(EncriptadorRSA moduloRSA) {
        this.moduloRSA = moduloRSA;
    }

    @Override
    public String toString() {
        return "PagoTarjeta{" + "ultimos4Digitos=" + ultimos4Digitos + ", moduloRSA=" + moduloRSA + '}';
    }
    public void tokenizarTarjeta(){
        System.out.println("Comportamiento propio de PagoTarjeta");
    }

    @Override
    public boolean procesarPago() {
       System.out.println("Comportamiento proceso pago");
        return true;
        
    }

    @Override
    public String obtenerHashConfirmacion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int numeroConfirmaciones() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
       
}
