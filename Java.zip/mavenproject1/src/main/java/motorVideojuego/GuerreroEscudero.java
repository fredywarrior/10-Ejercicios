/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorVideojuego;

/**
 *
 * @author UsuarioCompuElite
 */
public class GuerreroEscudero extends PersonajeRPG {
    private int armaduraPesada;
    //sin parametros

    public GuerreroEscudero() {
    }
    //con parametros

    public GuerreroEscudero(int armaduraPesada, String nombre, int puntosVida, int nivel) {
        super(nombre, puntosVida, nivel);
        this.armaduraPesada = armaduraPesada;
    }
    //getters

    public int getArmaduraPesada() {
        return armaduraPesada;
    }
    //setters

    public void setArmaduraPesada(int armaduraPesada) {
        this.armaduraPesada = armaduraPesada;
    }

    @Override
    public String toString() {
        return "GuerreroEscudero{" + "armaduraPesada=" + armaduraPesada + '}';
    }
    public void bloquearConEscudo(){
        System.out.println("Comportamiento base en GuerreroEscudero");
    }

    @Override
    public void atacar(PersonajeRPG objetivo) {
        System.out.println("Comportamiento atacar");
    }

    @Override
    public void ejecutarHabilidadEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int tiempoEnfrentamientoTurnos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
