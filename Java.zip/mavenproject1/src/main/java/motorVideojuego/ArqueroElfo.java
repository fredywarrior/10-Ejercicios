/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorVideojuego;

/**
 *
 * @author UsuarioCompuElite
 */
public class ArqueroElfo extends PersonajeRPG {
    private double precisionPorcentaje;
    //sin parametros

    public ArqueroElfo() {
    }
    //con parametros

    public ArqueroElfo(double precisionPorcentaje, String nombre, int puntosVida, int nivel) {
        super(nombre, puntosVida, nivel);
        this.precisionPorcentaje = precisionPorcentaje;
    }
    //getters

    public double getPrecisionPorcentaje() {
        return precisionPorcentaje;
    }
    //setters

    public void setPrecisionPorcentaje(double precisionPorcentaje) {
        this.precisionPorcentaje = precisionPorcentaje;
    }

    @Override
    public String toString() {
        return "ArqueroElfo{" + "precisionPorcentaje=" + precisionPorcentaje + '}';
    }

    @Override
    public void atacar(PersonajeRPG objetivo) {
        System.out.println("Comportamiento atacar");
    }

    @Override
    public void ejecutarHabilidadEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int tiempoEnfrentamientoTurnos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
