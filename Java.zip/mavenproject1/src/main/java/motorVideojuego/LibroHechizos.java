/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorVideojuego;

/**
 *
 * @author UsuarioCompuElite
 */
public class LibroHechizos {
    private int totalGrimorios;
    private String elementosDominante;
    //sin parametros

    public LibroHechizos() {
    }
    //con parametros

    public LibroHechizos(int totalGrimorios, String elementosDominante) {
        this.totalGrimorios = totalGrimorios;
        this.elementosDominante = elementosDominante;
    }
    //getters

    public int getTotalGrimorios() {
        return totalGrimorios;
    }

    public String getElementosDominante() {
        return elementosDominante;
    }
    //setters

    public void setTotalGrimorios(int totalGrimorios) {
        this.totalGrimorios = totalGrimorios;
    }

    public void setElementosDominante(String elementosDominante) {
        this.elementosDominante = elementosDominante;
    }

    @Override
    public String toString() {
        return "LibroHechizos{" + "totalGrimorios=" + totalGrimorios + ", elementosDominante=" + elementosDominante + '}';
    }
    public void buscarRunaPoderosa(){
        System.out.println("Comportamiento propio de LibroHechizos");
    }
}
