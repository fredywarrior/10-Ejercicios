/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorVideojuego;

/**
 *
 * @author UsuarioCompuElite
 */
public class MagoElemental extends PersonajeRPG{
    private int manaPool;
    private LibroHechizos grimorio;
    //sin parametros

    public MagoElemental() {
    }
    //con parametros

    public MagoElemental(int manaPool, LibroHechizos grimorio, String nombre, int puntosVida, int nivel) {
        super(nombre, puntosVida, nivel);
        this.manaPool = manaPool;
        this.grimorio = grimorio;
    }
    //getters

    public int getManaPool() {
        return manaPool;
    }

    public LibroHechizos getGrimorio() {
        return grimorio;
    }
    //Setters

    public void setManaPool(int manaPool) {
        this.manaPool = manaPool;
    }

    public void setGrimorio(LibroHechizos grimorio) {
        this.grimorio = grimorio;
    }

    @Override
    public String toString() {
        return "MagoElemental{" + "manaPool=" + manaPool + ", grimorio=" + grimorio + '}';
    }
    
    public void invocarTormenta(){
        System.out.println("Comportamiento de invocacion");
    }

    @Override
    public void atacar(PersonajeRPG objetivo) {
        System.out.println("Comportamiento atacar");
    }

    @Override
    public void ejecutarHabilidadEspecial() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int tiempoEnfrentamientoTurnos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
            
}
