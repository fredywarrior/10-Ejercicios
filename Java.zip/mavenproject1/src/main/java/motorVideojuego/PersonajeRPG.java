/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package motorVideojuego;

/**
 *
 * @author UsuarioCompuElite
 */
public abstract class PersonajeRPG implements LanzadorHabilidades{
    private String nombre;
    private int puntosVida;
    private int nivel;
    //sin parametros

    public PersonajeRPG() {
    }
    //con parametros

    public PersonajeRPG(String nombre, int puntosVida, int nivel) {
        this.nombre = nombre;
        this.puntosVida = puntosVida;
        this.nivel = nivel;
    }
    //getters

    public String getNombre() {
        return nombre;
    }

    public int getPuntosVida() {
        return puntosVida;
    }

    public int getNivel() {
        return nivel;
    }
    //setters

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPuntosVida(int puntosVida) {
        this.puntosVida = puntosVida;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "PersonajeRPG{" + "nombre=" + nombre + ", puntosVida=" + puntosVida + ", nivel=" + nivel + '}';
    }
    public abstract void atacar (PersonajeRPG objetivo);
    public int recibirDaño(int puntos){
        System.out.println("Comportamiento base en PersonajeRPG");
        return 0;
    }
}
